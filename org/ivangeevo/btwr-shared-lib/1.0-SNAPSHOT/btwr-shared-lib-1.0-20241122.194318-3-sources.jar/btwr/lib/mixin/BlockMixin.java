package btwr.lib.mixin;

import btwr.lib.added.BlockAdded;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2248.class)
public abstract class BlockMixin implements BlockAdded
{
    @Override
    public void notifyOfFullStagePlantGrowthOn(class_1937 world, class_2338 pos, class_2248 plantBlock) {}

    /**
     * This is used by old style non-daily plant growth
     */
    public float getPlantGrowthOnMultiplier(class_1937 world, class_2338 pos, class_2248 plantBlock) { return 1F; }

    @Override
    public boolean isBlockHydratedForPlantGrowthOn(class_1937 world, class_2338 pos) {return false;}

    @Override
    public int getWeedsGrowthLevel(class_1936 blockAccess, class_2338 pos)
    {
        return 0;
    }

    @Override
    public void removeWeeds(class_1937 world, class_2338 pos) {}
}

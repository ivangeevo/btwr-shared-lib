package btwr.lib.interfaces.added;

import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;

// version 1 = 18Nov 2024
public interface BlockAdded
{

    /**
     * Called when a plant hits a full growth stage, like wheat fully grown,
     * or each full block of Hemp.  Used to clear fertilizer.
     */
    default void notifyOfFullStagePlantGrowthOn(class_1937 world, class_2338 pos, class_2248 plantBlock) {}

    /**
     * This is used by old style non-daily plant growth
     */
    default float getPlantGrowthOnMultiplier(class_1937 world, class_2338 pos, class_2248 plantBlock) { return 0; }

    default boolean isBlockHydratedForPlantGrowthOn(class_1937 world, class_2338 pos) { return false; }

    /**
     * The growth level of weeds growing out of this block.  Range of 0 to 7
     */
    default int getWeedsGrowthLevel(class_1936 blockAccess, class_2338 pos) { return 0; }

    default void removeWeeds(class_1937 world, class_2338 pos) {}

}
